let version = "1.7"
let date = "Wed Feb 23 09:35:32 CET 2011"
